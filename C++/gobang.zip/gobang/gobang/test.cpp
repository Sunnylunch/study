#include<iostream>
#include<cstdio>
#include<cstdlib>
using namespace std;
#include"gobang.h"

void test()
{
	GoBang a;
	a.Play();
}

int main()
{
	test();
	system("pause");
	return 0;
}